# RAF INTERCEPT — Stage 2

A browser-based training game prototype. Stage 2 adds a schematic monochrome North Sea map, QRA selection/scramble, fighter status, vector commands, training assistance and scoring.

Run:
npm install
npm run dev

Next: proper intercept/CPA geometry, fuel endurance, Voyager tanker support, richer training/debrief and optional live ADS-B mode.
