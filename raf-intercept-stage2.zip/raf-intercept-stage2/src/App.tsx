import {useEffect,useMemo,useState} from 'react'

type Plane={id:string;name:string;x:number;y:number;heading:number;speed:number;alt:number;fuel:number;airborne:boolean;friendly:boolean}
type Base={id:string;name:string;x:number;y:number;ready:number;aircraft:number}

const bases:Base[]=[
 {id:'L',name:'LOSSIEMOUTH',x:31,y:12,ready:2,aircraft:2},
 {id:'C',name:'CONINGSBY',x:67,y:66,ready:2,aircraft:2},
]
const startTargets:Plane[]=[
 {id:'T421',name:'TRACK 421',x:87,y:31,heading:235,speed:430,alt:280,fuel:100,airborne:true,friendly:false},
 {id:'T315',name:'TRACK 315',x:12,y:78,heading:35,speed:390,alt:240,fuel:100,airborne:true,friendly:false},
]
const startFighters:Plane[]=[
 {id:'F21',name:'TYPHOON 21',x:67,y:66,heading:315,speed:450,alt:250,fuel:88,airborne:false,friendly:true},
 {id:'F22',name:'TYPHOON 22',x:31,y:12,heading:135,speed:450,alt:250,fuel:78,airborne:false,friendly:true},
]
const clamp=(n:number,a=4,b=96)=>Math.max(a,Math.min(b,n))
function move(p:Plane,dt:number){const r=p.heading*Math.PI/180,s=.00115;return {...p,x:clamp(p.x+Math.sin(r)*p.speed*dt*s),y:clamp(p.y-Math.cos(r)*p.speed*dt*s)}}
function dist(a:Plane,b:Plane){return Math.hypot(a.x-b.x,a.y-b.y)}
function brg(a:Plane,b:Plane){let d=Math.atan2(b.x-a.x,-(b.y-a.y))*180/Math.PI;return Math.round((d+360)%360)}
function angular(a:number,b:number){return Math.abs(((a-b+540)%360)-180)}

export default function App(){
 const [targets,setTargets]=useState(startTargets),[fighters,setFighters]=useState(startFighters)
 const [selT,setSelT]=useState('T421'),[selF,setSelF]=useState('F21'),[vector,setVector]=useState(285)
 const [selectedBase,setSelectedBase]=useState('C'),[score,setScore]=useState(0),[running,setRunning]=useState(true)
 const [msg,setMsg]=useState('CONTACT! Assess the track and select the most suitable QRA.')
 const [assist,setAssist]=useState(true),[scrambled,setScrambled]=useState<string[]>([])
 const target=targets.find(p=>p.id===selT)!,fighter=fighters.find(p=>p.id===selF)!
 const range=dist(fighter,target)*14, bearing=brg(fighter,target)
 const eta=Math.max(0,range/Math.max(1,fighter.speed-target.speed*.35)*60)
 const suggested=useMemo(()=>Math.round((bearing + angular(target.heading,bearing)*0.7 + target.heading*0.3)%360),[bearing,target.heading])
 useEffect(()=>{if(!running)return;const id=setInterval(()=>{setTargets(ts=>ts.map(t=>move(t,1)));setFighters(fs=>fs.map(f=>f.airborne?{...move(f,1),fuel:Math.max(0,f.fuel-.035)}:f))},1000);return()=>clearInterval(id)},[running])
 function scramble(){
   if(scrambled.includes(selF)){setMsg(`${fighter.name} already airborne.`);return}
   setScrambled(s=>[...s,selF]);setFighters(fs=>fs.map(f=>f.id===selF?{...f,airborne:true}:f))
   const b=bases.find(b=>b.id===selectedBase)!
   const d=Math.hypot(fighter.x-b.x,fighter.y-b.y)
   const qraScore=Math.max(0,150-Math.round(d*4))
   setScore(s=>s+qraScore);setMsg(`${b.name} QRA scrambled. ${qraScore} points for QRA selection.`)
 }
 function issueVector(){
   if(!fighter.airborne){setMsg('FIGHTER NOT AIRBORNE — SCRAMBLE QRA FIRST.');return}
   const e=angular(vector,suggested),pts=Math.max(0,120-Math.round(e*2))
   setScore(s=>s+pts);setFighters(fs=>fs.map(f=>f.id===selF?{...f,heading:vector}:f))
   if(dist(fighter,target)<10){setScore(s=>s+500);setMsg(`INTERCEPT ACHIEVED. ${pts+500} points.`)}
   else setMsg(e<=10?`GOOD VECTOR. ${pts} points.`:`VECTOR ACCEPTED. ${pts} points. Refine the lead.`)
 }
 function reset(){setTargets(startTargets);setFighters(startFighters);setScrambled([]);setScore(0);setRunning(true);setMsg('NEW SCENARIO — CONTACT!')}
 return <main>
  <header><div><div className="eyebrow">AIR DEFENCE TRAINING SYSTEM</div><h1>RAF INTERCEPT <span>STAGE 2</span></h1></div><div className="status"><b>SECTOR:</b> NORTH SEA / UK EAST <i>● LIVE</i></div></header>
  <section className="layout">
   <div className="map">
    <div className="gridlines"/><div className="sea-label">NORTH SEA</div>
    <div className="land uk"><span>UNITED KINGDOM</span></div><div className="land eu"><span>CONTINENTAL EUROPE</span></div>
    {bases.map(b=><button key={b.id} className={`base ${selectedBase===b.id?'chosen':''}`} style={{left:`${b.x}%`,top:`${b.y}%`}} onClick={()=>setSelectedBase(b.id)}>✦<small>{b.name}</small></button>)}
    {targets.map(t=><button key={t.id} className={`contact target ${selT===t.id?'selected':''}`} style={{left:`${t.x}%`,top:`${t.y}%`}} onClick={()=>setSelT(t.id)}>◆<small>{t.name}</small></button>)}
    {fighters.map(f=><button key={f.id} className={`contact fighter ${selF===f.id?'selected':''} ${f.airborne?'airborne':''}`} style={{left:`${f.x}%`,top:`${f.y}%`}} onClick={()=>setSelF(f.id)}>▲<small>{f.name}</small></button>)}
    <div className="mapnote">SCHEMATIC GAME MAP — NOT FOR NAVIGATION</div>
   </div>
   <aside>
    <div className="panel"><h2>CONTACT ASSESSMENT</h2><div className="big">{target.name}</div><div className="grid">
     <label>BRG <strong>{bearing.toString().padStart(3,'0')}°</strong></label><label>RNG <strong>{range.toFixed(0)} NM</strong></label>
     <label>SPD <strong>{target.speed} KT</strong></label><label>ALT <strong>FL{target.alt}</strong></label>
     <label>HDG <strong>{target.heading.toString().padStart(3,'0')}°</strong></label><label>ETA <strong>{eta.toFixed(1)} MIN</strong></label>
    </div></div>
    <div className="panel"><h2>QRA SELECTION</h2>{bases.map(b=><button className={`baseRow ${selectedBase===b.id?'active':''}`} key={b.id} onClick={()=>setSelectedBase(b.id)}><span>{b.name}</span><b>{b.aircraft} READY</b></button>)}<button className="primary" onClick={scramble}>SCRAMBLE SELECTED QRA</button></div>
    <div className="panel"><h2>FIGHTER STATUS</h2><select value={selF} onChange={e=>setSelF(e.target.value)}>{fighters.map(f=><option key={f.id} value={f.id}>{f.name} — {f.airborne?'AIRBORNE':'QRA'} — {Math.round(f.fuel)}%</option>)}</select><div className="grid"><label>STATE <strong>{fighter.airborne?'AIRBORNE':'QRA'}</strong></label><label>FUEL <strong>{Math.round(fighter.fuel)}%</strong></label><label>HDG <strong>{fighter.heading.toString().padStart(3,'0')}°</strong></label><label>SPD <strong>{fighter.speed} KT</strong></label></div></div>
    <div className="panel"><h2>VECTOR COMMAND</h2><input type="range" min="0" max="359" value={vector} onChange={e=>setVector(+e.target.value)}/><div className="vector"><span>VECTOR</span><strong>{vector.toString().padStart(3,'0')}°</strong></div>{assist&&<div className="hint">TRAINING: suggested vector {suggested.toString().padStart(3,'0')}°</div>}<button className="primary" onClick={issueVector}>ISSUE VECTOR</button></div>
    <div className="panel"><h2>CONTROLLER ASSESSMENT</h2><div className="score">{score}</div><p className="message">{msg}</p><label className="toggle"><input type="checkbox" checked={assist} onChange={e=>setAssist(e.target.checked)}/> Training assistance</label><div className="actions"><button onClick={()=>setRunning(!running)}>{running?'PAUSE':'RESUME'}</button><button onClick={reset}>NEW SCENARIO</button></div></div>
   </aside>
  </section>
 </main>
}